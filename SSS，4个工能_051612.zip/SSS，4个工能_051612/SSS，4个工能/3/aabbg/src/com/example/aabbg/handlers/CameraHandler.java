package com.example.aabbg.handlers;

import android.content.Context;
import android.hardware.Camera;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import android.widget.Toast;

@SuppressWarnings("deprecation") // 暂时使用旧API
public class CameraHandler {
    private final Context context;
    private Camera camera;
    private boolean isFrontCamera = false;
    private int currentOrientation = 0;

    public CameraHandler(Context context) {
        this.context = context;
    }

    public void openCamera(boolean front, SurfaceHolder holder) {
        releaseCamera();
        try {
            int cameraId = front ? getFrontCameraId() : getBackCameraId();
            if (cameraId == -1) {
                showToast("找不到" + (front ? "前置" : "后置") + "摄像头");
                return;
            }

            camera = Camera.open(cameraId);
            if (camera == null) {
                showToast("无法打开相机");
                return;
            }

            setupCamera(holder);
            isFrontCamera = front;
        } catch (Exception e) {
            showToast("打开相机失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showToast(final String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    private void setupCamera(SurfaceHolder holder) throws Exception {
        if (camera == null || holder == null) return;

        try {
            camera.setPreviewDisplay(holder);
            
            Camera.Parameters parameters = camera.getParameters();
            if (parameters == null) return;

            // 设置预览尺寸
            Camera.Size previewSize = getBestPreviewSize(parameters);
            if (previewSize != null) {
                parameters.setPreviewSize(previewSize.width, previewSize.height);
            }

            // 设置对焦模式
            if (parameters.getSupportedFocusModes().contains(
                Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            }

            // 设置场景模式
            if (parameters.getSupportedSceneModes().contains(
                Camera.Parameters.SCENE_MODE_AUTO)) {
                parameters.setSceneMode(Camera.Parameters.SCENE_MODE_AUTO);
            }

            // 设置白平衡
            if (parameters.getSupportedWhiteBalance().contains(
                Camera.Parameters.WHITE_BALANCE_AUTO)) {
                parameters.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_AUTO);
            }

            // 设置闪光灯模式
            if (!isFrontCamera && parameters.getSupportedFlashModes() != null && 
                parameters.getSupportedFlashModes().contains(
                    Camera.Parameters.FLASH_MODE_AUTO)) {
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_AUTO);
            }

            camera.setParameters(parameters);

            // 设置预览方向
            setCameraDisplayOrientation();
            
            camera.startPreview();
        } catch (Exception e) {
            throw new Exception("设置相机参数失败: " + e.getMessage());
        }
    }

    private Camera.Size getBestPreviewSize(Camera.Parameters parameters) {
        Camera.Size result = null;
        int targetWidth = 1920; // 目标宽度
        int targetHeight = 1080; // 目标高度
        double minDiff = Double.MAX_VALUE;

        for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
            if (size.width >= targetWidth && size.height >= targetHeight) {
                double ratio = (double) size.width / size.height;
                if (Math.abs(ratio - (16.0 / 9.0)) < minDiff) {
                    result = size;
                    minDiff = Math.abs(ratio - (16.0 / 9.0));
                }
            }
        }

        // 如果没找到合适的，就用最大的尺寸
        if (result == null) {
            int maxArea = 0;
            for (Camera.Size size : parameters.getSupportedPreviewSizes()) {
                int area = size.width * size.height;
                if (area > maxArea) {
                    maxArea = area;
                    result = size;
                }
            }
        }

        return result;
    }

    private void setCameraDisplayOrientation() {
        if (camera == null || context == null) return;

        WindowManager windowManager = 
            (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager == null) return;

        int rotation = windowManager.getDefaultDisplay().getRotation();
        int degrees = 0;

        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(isFrontCamera ? 
            getFrontCameraId() : getBackCameraId(), info);

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;
        } else {
            result = (info.orientation - degrees + 360) % 360;
        }

        currentOrientation = result;
        camera.setDisplayOrientation(result);
    }

    private int getFrontCameraId() {
        return getCameraId(Camera.CameraInfo.CAMERA_FACING_FRONT);
    }

    private int getBackCameraId() {
        return getCameraId(Camera.CameraInfo.CAMERA_FACING_BACK);
    }

    private int getCameraId(int facing) {
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == facing) {
                return i;
            }
        }
        return -1;
    }

    public void releaseCamera() {
        if (camera != null) {
            try {
                camera.stopPreview();
                camera.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
            camera = null;
        }
    }

    public boolean isFrontCamera() {
        return isFrontCamera;
    }

    public int getCurrentOrientation() {
        return currentOrientation;
    }
}