package com.example.aabbg.handlers;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CameraHandler {
    private Context context;
    private CameraManager cameraManager;
    private CameraDevice frontCamera;
    private CameraDevice backCamera;
    private CameraCaptureSession frontSession;
    private CameraCaptureSession backSession;
    private ImageReader frontImageReader;
    private ImageReader backImageReader;
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;
    private boolean isFlashOn = false;
    
    private static final String SAVE_PATH = "/storage/emulated/0/11/";

    public CameraHandler(Context context) {
        this.context = context;
        this.cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        startBackgroundThread();
        createSaveDirectory();
    }

    private void createSaveDirectory() {
        File directory = new File(SAVE_PATH);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void startBothCameras(final SurfaceHolder frontHolder, final SurfaceHolder backHolder) {
        try {
            String[] cameraIds = cameraManager.getCameraIdList();
            
            for (String cameraId : cameraIds) {
                CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(cameraId);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                
                if (facing != null) {
                    if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                        setupCamera(cameraId, frontHolder, true);
                    } else if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                        setupCamera(cameraId, backHolder, false);
                    }
                }
            }
        } catch (CameraAccessException e) {
            Toast.makeText(context, "无法访问相机: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void setupCamera(final String cameraId, final SurfaceHolder holder, final boolean isFront) {
        try {
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(final CameraDevice camera) {
                    if (isFront) {
                        frontCamera = camera;
                    } else {
                        backCamera = camera;
                    }
                    try {
                        final Surface previewSurface = holder.getSurface();
                        final CaptureRequest.Builder previewRequestBuilder = 
                            camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        previewRequestBuilder.addTarget(previewSurface);

                        camera.createCaptureSession(Arrays.asList(previewSurface),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession session) {
                                    if (camera == null) {
                                        return;
                                    }

                                    if (isFront) {
                                        frontSession = session;
                                    } else {
                                        backSession = session;
                                    }

                                    try {
                                        previewRequestBuilder.set(CaptureRequest.CONTROL_MODE,
                                            CaptureRequest.CONTROL_MODE_AUTO);
                                        session.setRepeatingRequest(previewRequestBuilder.build(),
                                            null, backgroundHandler);
                                    } catch (CameraAccessException e) {
                                        e.printStackTrace();
                                    }
                                }

                                @Override
                                public void onConfigureFailed(CameraCaptureSession session) {
                                    Toast.makeText(context, "创建相机预览失败", 
                                        Toast.LENGTH_SHORT).show();
                                }
                            }, backgroundHandler);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    if (isFront) {
                        frontCamera = null;
                    } else {
                        backCamera = null;
                    }
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    if (isFront) {
                        frontCamera = null;
                    } else {
                        backCamera = null;
                    }
                    Toast.makeText(context, "相机错误: " + error, 
                        Toast.LENGTH_SHORT).show();
                }
            }, backgroundHandler);
        } catch (CameraAccessException | SecurityException e) {
            Toast.makeText(context, "相机访问错误: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    public void takePhoto() {
        if (backCamera != null) {
            takePicture(backCamera, false);
        }
        if (frontCamera != null) {
            takePicture(frontCamera, true);
        }
    }

    private void takePicture(final CameraDevice camera, final boolean isFront) {
        try {
            final ImageReader reader = ImageReader.newInstance(1920, 1080, 
                android.graphics.ImageFormat.JPEG, 1);
            
            List<Surface> outputSurfaces = new ArrayList<>();
            outputSurfaces.add(reader.getSurface());
            
            final CaptureRequest.Builder captureBuilder = 
                camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(reader.getSurface());
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);

            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader imageReader) {
                    Image image = null;
                    try {
                        image = imageReader.acquireLatestImage();
                        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                        byte[] bytes = new byte[buffer.capacity()];
                        buffer.get(bytes);
                        save(bytes, isFront);
                    } finally {
                        if (image != null) {
                            image.close();
                        }
                    }
                }
            }, backgroundHandler);

            CameraCaptureSession session = isFront ? frontSession : backSession;
            if (session != null) {
                session.stopRepeating();
                session.capture(captureBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                    @Override
                    public void onCaptureCompleted(CameraCaptureSession session,
                        CaptureRequest request, TotalCaptureResult result) {
                        try {
                            session.setRepeatingRequest(session.getDevice()
                                .createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                .build(), null, backgroundHandler);
                        } catch (CameraAccessException e) {
                            e.printStackTrace();
                        }
                    }
                }, backgroundHandler);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void save(byte[] bytes, boolean isFront) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", 
            Locale.getDefault()).format(new Date());
        String filename = (isFront ? "front_" : "back_") + timestamp + ".jpg";
        File file = new File(SAVE_PATH + filename);
        
        try (FileOutputStream output = new FileOutputStream(file)) {
            output.write(bytes);
            Toast.makeText(context, "照片已保存: " + file.getPath(), 
                Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(context, "保存照片失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    public void toggleFlash() {
        if (backSession == null) return;

        try {
            CaptureRequest.Builder builder = backCamera
                .createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.set(CaptureRequest.FLASH_MODE, 
                isFlashOn ? CaptureRequest.FLASH_MODE_OFF : CaptureRequest.FLASH_MODE_TORCH);
            backSession.setRepeatingRequest(builder.build(), null, backgroundHandler);
            isFlashOn = !isFlashOn;
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void zoomIn() {
        // Camera2 API的变焦功能需要更复杂的实现
        // 这里暂时留空
    }

    public void zoomOut() {
        // Camera2 API的变焦功能需要更复杂的实现
        // 这里暂时留空
    }

    public void releaseCamera() {
        if (frontSession != null) {
            frontSession.close();
            frontSession = null;
        }
        if (backSession != null) {
            backSession.close();
            backSession = null;
        }
        if (frontCamera != null) {
            frontCamera.close();
            frontCamera = null;
        }
        if (backCamera != null) {
            backCamera.close();
            backCamera = null;
        }
        if (frontImageReader != null) {
            frontImageReader.close();
            frontImageReader = null;
        }
        if (backImageReader != null) {
            backImageReader.close();
            backImageReader = null;
        }
        stopBackgroundThread();
    }
}