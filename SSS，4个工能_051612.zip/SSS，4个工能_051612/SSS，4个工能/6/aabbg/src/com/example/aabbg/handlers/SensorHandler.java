package com.example.aabbg.handlers;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;
import android.graphics.Color;
import android.widget.TextView;
import java.util.Locale;

public class SensorHandler implements SensorEventListener {
    private TextView txtSensorData;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor gravity;
    
    // 用于存储传感器数据
    private float[] accelValues = new float[3];
    private float[] gyroValues = new float[3];
    private float[] gravityValues = new float[3];
    
    // 更新频率控制
    private long lastUpdate = 0;
    private static final long UPDATE_INTERVAL = 100; // 100ms更新一次
    
    // 阈值设置
    private static final float MOVEMENT_THRESHOLD = 0.8f;
    private static final double TILT_THRESHOLD = 2.5;

    public SensorHandler(Context context, TextView txtSensorData) {
        this.txtSensorData = txtSensorData;
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            gravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        }
    }

    public void startSensorMonitoring() {
        if (sensorManager != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_GAME);
            sensorManager.registerListener(this, gravity, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public void stopSensorMonitoring() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
                System.arraycopy(event.values, 0, accelValues, 0, 3);
                break;
            case Sensor.TYPE_GYROSCOPE:
                System.arraycopy(event.values, 0, gyroValues, 0, 3);
                break;
            case Sensor.TYPE_GRAVITY:
                System.arraycopy(event.values, 0, gravityValues, 0, 3);
                break;
        }

        long currentTime = System.currentTimeMillis();
        if (currentTime - lastUpdate > UPDATE_INTERVAL) {
            lastUpdate = currentTime;
            updateDisplay();
        }
    }

    private void updateDisplay() {
        StringBuilder display = new StringBuilder();
        
        // 计算水平倾斜角度
        double tiltAngleX = Math.toDegrees(Math.atan2(gravityValues[0], gravityValues[2]));
        double tiltAngleY = Math.toDegrees(Math.atan2(gravityValues[1], gravityValues[2]));
        
        // 添加水平状态提示
        display.append("=== 手机平衡状态 ===\n");
        if (Math.abs(tiltAngleX) < TILT_THRESHOLD && Math.abs(tiltAngleY) < TILT_THRESHOLD) {
            display.append("手机处于水平状态\n");
        } else {
            if (Math.abs(tiltAngleX) > TILT_THRESHOLD) {
                display.append(tiltAngleX > 0 ? "向右倾斜 " : "向左倾斜 ");
                display.append(String.format(Locale.getDefault(), "%.1f°\n", Math.abs(tiltAngleX)));
            }
            if (Math.abs(tiltAngleY) > TILT_THRESHOLD) {
                display.append(tiltAngleY > 0 ? "向前倾斜 " : "向后倾斜 ");
                display.append(String.format(Locale.getDefault(), "%.1f°\n", Math.abs(tiltAngleY)));
            }
        }
        
        // 添加空行
        display.append("\n");
        
        // 陀螺仪数据显示
        display.append("=== 陀螺仪数据 ===\n");
        display.append(String.format(Locale.getDefault(), 
            "X轴旋转速度: %.2f °/s\n" +
            "Y轴旋转速度: %.2f °/s\n" +
            "Z轴旋转速度: %.2f °/s\n",
            Math.toDegrees(gyroValues[0]),
            Math.toDegrees(gyroValues[1]),
            Math.toDegrees(gyroValues[2])));
        
        // 添加旋转状态描述
        display.append("旋转状态: ");
        if (Math.abs(gyroValues[0]) > MOVEMENT_THRESHOLD) {
            display.append(gyroValues[0] > 0 ? "前翻 " : "后翻 ");
        }
        if (Math.abs(gyroValues[1]) > MOVEMENT_THRESHOLD) {
            display.append(gyroValues[1] > 0 ? "右转 " : "左转 ");
        }
        if (Math.abs(gyroValues[2]) > MOVEMENT_THRESHOLD) {
            display.append(gyroValues[2] > 0 ? "顺时针 " : "逆时针 ");
        }
        if (Math.abs(gyroValues[0]) <= MOVEMENT_THRESHOLD && 
            Math.abs(gyroValues[1]) <= MOVEMENT_THRESHOLD && 
            Math.abs(gyroValues[2]) <= MOVEMENT_THRESHOLD) {
            display.append("静止");
        }
        display.append("\n\n");
        
        // 加速度计数据
        display.append("=== 加速度数据 ===\n");
        display.append(String.format(Locale.getDefault(),
            "X轴加速度: %.2f m/s²\n" +
            "Y轴加速度: %.2f m/s²\n" +
            "Z轴加速度: %.2f m/s²\n",
            accelValues[0], accelValues[1], accelValues[2]));
        
        // 检测是否有显著运动
        boolean isMoving = Math.abs(accelValues[0]) > MOVEMENT_THRESHOLD * 2 ||
                         Math.abs(accelValues[1]) > MOVEMENT_THRESHOLD * 2 ||
                         Math.abs(accelValues[2] - SensorManager.GRAVITY_EARTH) > MOVEMENT_THRESHOLD * 2;
        
        txtSensorData.setText(display.toString());
        
        // 根据运动状态改变文字颜色
        if (isMoving) {
            txtSensorData.setTextColor(Color.parseColor("#FFA500")); // 橙色
        } else {
            txtSensorData.setTextColor(Color.BLACK);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 精度变化时的处理
    }
}