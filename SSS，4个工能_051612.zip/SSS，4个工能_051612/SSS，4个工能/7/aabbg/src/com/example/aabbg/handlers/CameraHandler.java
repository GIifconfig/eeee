package com.example.aabbg.handlers;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class CameraHandler {
    private Context context;
    private CameraManager cameraManager;
    private CameraDevice frontCamera;
    private CameraDevice backCamera;
    private CameraCaptureSession frontSession;
    private CameraCaptureSession backSession;
    private ImageReader frontImageReader;
    private ImageReader backImageReader;
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;
    private boolean isFlashOn = false;
    
    private float frontCurrentZoom = 1.0f;
    private float backCurrentZoom = 1.0f;
    private float frontMaxZoom = 1.0f;
    private float backMaxZoom = 1.0f;
    private Rect frontSensorSize;
    private Rect backSensorSize;
    private Surface frontPreviewSurface;
    private Surface backPreviewSurface;
    
    private static final int IMAGE_WIDTH = 1920;
    private static final int IMAGE_HEIGHT = 1080;
    private static final String SAVE_PATH = "/storage/emulated/0/11/";
    private final Semaphore cameraOpenCloseLock = new Semaphore(1);

    public CameraHandler(Context context) {
        this.context = context;
        this.cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        startBackgroundThread();
        createSaveDirectory();
        setupImageReaders();
    }

    private void setupImageReaders() {
        frontImageReader = ImageReader.newInstance(IMAGE_WIDTH, IMAGE_HEIGHT, 
            ImageFormat.JPEG, 2);
        backImageReader = ImageReader.newInstance(IMAGE_WIDTH, IMAGE_HEIGHT, 
            ImageFormat.JPEG, 2);

        ImageReader.OnImageAvailableListener imageListener = new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                boolean isFront = reader == frontImageReader;
                backgroundHandler.post(new ImageSaver(reader.acquireNextImage(), isFront));
            }
        };

        frontImageReader.setOnImageAvailableListener(imageListener, backgroundHandler);
        backImageReader.setOnImageAvailableListener(imageListener, backgroundHandler);
    }

    private class ImageSaver implements Runnable {
        private final Image image;
        private final boolean isFront;

        ImageSaver(Image image, boolean isFront) {
            this.image = image;
            this.isFront = isFront;
        }

        @Override
        public void run() {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.capacity()];
            buffer.get(bytes);
            save(bytes, isFront);
            image.close();
        }
    }

    private void createSaveDirectory() {
        File directory = new File(SAVE_PATH);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void startBothCameras(final SurfaceHolder frontHolder, final SurfaceHolder backHolder) {
        try {
            String[] cameraIds = cameraManager.getCameraIdList();
            
            for (String cameraId : cameraIds) {
                CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(cameraId);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                
                if (facing != null) {
                    if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                        frontPreviewSurface = frontHolder.getSurface();
                        setupCamera(cameraId, frontHolder, true);
                        frontSensorSize = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                        Float maxZoom = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                        if (maxZoom != null) {
                            frontMaxZoom = maxZoom;
                        }
                    } else if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                        backPreviewSurface = backHolder.getSurface();
                        setupCamera(cameraId, backHolder, false);
                        backSensorSize = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                        Float maxZoom = characteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                        if (maxZoom != null) {
                            backMaxZoom = maxZoom;
                        }
                    }
                }
            }
        } catch (CameraAccessException e) {
            Toast.makeText(context, "无法访问相机: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void setupCamera(final String cameraId, final SurfaceHolder holder, final boolean isFront) {
        try {
            if (!cameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                throw new RuntimeException("相机打开超时");
            }
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(final CameraDevice camera) {
                    cameraOpenCloseLock.release();
                    if (isFront) {
                        frontCamera = camera;
                    } else {
                        backCamera = camera;
                    }
                    createCameraPreviewSession(camera, holder, isFront);
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    cameraOpenCloseLock.release();
                    camera.close();
                    if (isFront) {
                        frontCamera = null;
                    } else {
                        backCamera = null;
                    }
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    cameraOpenCloseLock.release();
                    camera.close();
                    if (isFront) {
                        frontCamera = null;
                    } else {
                        backCamera = null;
                    }
                    Toast.makeText(context, "相机错误: " + error, 
                        Toast.LENGTH_SHORT).show();
                }
            }, backgroundHandler);
        } catch (CameraAccessException | InterruptedException | SecurityException e) {
            e.printStackTrace();
            Toast.makeText(context, "相机访问错误: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void createCameraPreviewSession(final CameraDevice camera, SurfaceHolder holder, 
        final boolean isFront) {
        try {
            final Surface previewSurface = holder.getSurface();
            List<Surface> surfaces = new ArrayList<>();
            surfaces.add(previewSurface);
            
            final ImageReader imageReader = isFront ? frontImageReader : backImageReader;
            surfaces.add(imageReader.getSurface());

            final CaptureRequest.Builder previewRequestBuilder = 
                camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            previewRequestBuilder.addTarget(previewSurface);

            camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    try {
                        if (isFront) {
                            frontSession = session;
                        } else {
                            backSession = session;
                        }

                        previewRequestBuilder.set(CaptureRequest.CONTROL_MODE,
                            CaptureRequest.CONTROL_MODE_AUTO);
                        
                        final Rect sensorSize = isFront ? frontSensorSize : backSensorSize;
                        final float currentZoom = isFront ? frontCurrentZoom : backCurrentZoom;
                        
                        if (sensorSize != null) {
                            previewRequestBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                                getZoomRect(sensorSize, currentZoom));
                        }
                        
                        session.setRepeatingRequest(previewRequestBuilder.build(),
                            null, backgroundHandler);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    Toast.makeText(context, "创建相机预览失败", 
                        Toast.LENGTH_SHORT).show();
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void setFrontZoom(float zoom) {
        if (frontCamera == null || frontSensorSize == null || frontSession == null) return;
        
        frontCurrentZoom = Math.max(1.0f, Math.min(zoom, frontMaxZoom));
        updateZoom(true);
    }

    public void setBackZoom(float zoom) {
        if (backCamera == null || backSensorSize == null || backSession == null) return;
        
        backCurrentZoom = Math.max(1.0f, Math.min(zoom, backMaxZoom));
        updateZoom(false);
    }

    private void updateZoom(final boolean isFront) {
        try {
            final CameraDevice camera = isFront ? frontCamera : backCamera;
            final CameraCaptureSession session = isFront ? frontSession : backSession;
            final Rect sensorSize = isFront ? frontSensorSize : backSensorSize;
            final float currentZoom = isFront ? frontCurrentZoom : backCurrentZoom;
            final Surface previewSurface = isFront ? frontPreviewSurface : backPreviewSurface;
            
            if (camera == null || session == null || sensorSize == null || previewSurface == null) return;

            CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(previewSurface);
            
            Rect zoomRect = getZoomRect(sensorSize, currentZoom);
            builder.set(CaptureRequest.SCALER_CROP_REGION, zoomRect);
            
            session.setRepeatingRequest(builder.build(), null, backgroundHandler);
            
            Toast.makeText(context, String.format(Locale.getDefault(), 
                "%s摄像头变焦: %.1f", isFront ? "前置" : "后置", currentZoom), 
                Toast.LENGTH_SHORT).show();
        } catch (CameraAccessException e) {
            e.printStackTrace();
            Toast.makeText(context, "设置变焦失败", Toast.LENGTH_SHORT).show();
        }
    }

    private Rect getZoomRect(Rect sensorSize, float zoomLevel) {
        int centerX = sensorSize.width() / 2;
        int centerY = sensorSize.height() / 2;
        int deltaX = (int)((0.5f * sensorSize.width()) / zoomLevel);
        int deltaY = (int)((0.5f * sensorSize.height()) / zoomLevel);
        
        return new Rect(
            centerX - deltaX,
            centerY - deltaY,
            centerX + deltaX,
            centerY + deltaY
        );
    }

    public void takeFrontPhoto() {
        if (frontCamera != null) {
            takePicture(frontCamera, true);
        }
    }

    public void takeBackPhoto() {
        if (backCamera != null) {
            takePicture(backCamera, false);
        }
    }

    public void takeBothPhotos() {
        if (frontCamera != null) {
            takePicture(frontCamera, true);
        }
        if (backCamera != null) {
            takePicture(backCamera, false);
        }
    }

    private void takePicture(final CameraDevice camera, final boolean isFront) {
        try {
            final ImageReader reader = isFront ? frontImageReader : backImageReader;
            final Surface previewSurface = isFront ? frontPreviewSurface : backPreviewSurface;
            final CameraCaptureSession captureSession = isFront ? frontSession : backSession;
            final Rect sensorSize = isFront ? frontSensorSize : backSensorSize;
            final float currentZoom = isFront ? frontCurrentZoom : backCurrentZoom;

            if (camera == null || captureSession == null || reader == null || 
                previewSurface == null || sensorSize == null) {
                return;
            }

            final CaptureRequest.Builder captureBuilder = 
                camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(reader.getSurface());
            
            // 设置照片的变焦
            captureBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                getZoomRect(sensorSize, currentZoom));

            // 设置自动对焦模式
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);

            // 设置自动曝光模式
            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);

            captureSession.stopRepeating();
            captureSession.capture(captureBuilder.build(), 
                new CameraCaptureSession.CaptureCallback() {
                    @Override
                    public void onCaptureCompleted(CameraCaptureSession session,
                        CaptureRequest request, TotalCaptureResult result) {
                        try {
                            // 恢复预览
                            final CaptureRequest.Builder previewBuilder = 
                                camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                            previewBuilder.addTarget(previewSurface);
                            previewBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                                getZoomRect(sensorSize, currentZoom));
                            session.setRepeatingRequest(previewBuilder.build(), 
                                null, backgroundHandler);
                        } catch (CameraAccessException e) {
                            e.printStackTrace();
                        }
                    }
                }, backgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
            Toast.makeText(context, "拍照失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void save(byte[] bytes, boolean isFront) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", 
            Locale.getDefault()).format(new Date());
        String filename = (isFront ? "front_" : "back_") + timestamp + ".jpg";
        File file = new File(SAVE_PATH + filename);
        
        try (FileOutputStream output = new FileOutputStream(file)) {
            output.write(bytes);
            Toast.makeText(context, "照片已保存: " + file.getPath(), 
                Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(context, "保存照片失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    public void toggleFlash() {
        if (backCamera == null || backSession == null) {
            Toast.makeText(context, "后置摄像头未就绪", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String cameraId = backCamera.getId();
            CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(cameraId);
            Boolean hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            
            if (hasFlash != null && hasFlash) {
                CaptureRequest.Builder builder = 
                    backCamera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                builder.addTarget(backPreviewSurface);
                
                isFlashOn = !isFlashOn;
                builder.set(CaptureRequest.FLASH_MODE,
                    isFlashOn ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
                
                // 保持变焦设置
                if (backSensorSize != null) {
                    builder.set(CaptureRequest.SCALER_CROP_REGION,
                        getZoomRect(backSensorSize, backCurrentZoom));
                }
                
                backSession.stopRepeating();
                backSession.setRepeatingRequest(builder.build(), null, backgroundHandler);
                
                Toast.makeText(context, isFlashOn ? "闪光灯已开启" : "闪光灯已关闭", 
                    Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "此设备不支持闪光灯", Toast.LENGTH_SHORT).show();
            }
        } catch (CameraAccessException e) {
            Toast.makeText(context, "闪光灯控制失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void releaseCamera() {
        try {
            cameraOpenCloseLock.acquire();
            if (frontSession != null) {
                frontSession.close();
                frontSession = null;
            }
            if (backSession != null) {
                backSession.close();
                backSession = null;
            }
            if (frontCamera != null) {
                frontCamera.close();
                frontCamera = null;
            }
            if (backCamera != null) {
                backCamera.close();
                backCamera = null;
            }
            if (frontImageReader != null) {
                frontImageReader.close();
                frontImageReader = null;
            }
            if (backImageReader != null) {
                backImageReader.close();
                backImageReader = null;
            }
        } catch (InterruptedException e) {
            throw new RuntimeException("相机关闭中断", e);
        } finally {
            cameraOpenCloseLock.release();
            stopBackgroundThread();
        }
    }
}