package com.example.aabbg.handlers;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.TextView;

import java.util.Locale;

public class SensorHandler implements SensorEventListener {
    private SensorManager sensorManager;
    private TextView textView;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor magnetometer;
    private StringBuilder sensorData;
    
    public SensorHandler(Context context, TextView textView) {
        this.textView = textView;
        this.sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        this.accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        this.gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        this.magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        this.sensorData = new StringBuilder();
    }
    
    public void startSensorMonitoring() {
        if (sensorManager != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);
        }
    }
    
    public void stopSensorMonitoring() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }
    
    @Override
    public void onSensorChanged(SensorEvent event) {
        sensorData.setLength(0);
        
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
                sensorData.append("加速度传感器 (m/s²):\n");
                sensorData.append(String.format(Locale.getDefault(), 
                    "X: %.2f\nY: %.2f\nZ: %.2f\n\n", 
                    event.values[0], event.values[1], event.values[2]));
                break;
                
            case Sensor.TYPE_GYROSCOPE:
                sensorData.append("陀螺仪 (rad/s):\n");
                sensorData.append(String.format(Locale.getDefault(), 
                    "X: %.2f\nY: %.2f\nZ: %.2f\n\n",
                    event.values[0], event.values[1], event.values[2]));
                break;
                
            case Sensor.TYPE_MAGNETIC_FIELD:
                sensorData.append("磁力计 (μT):\n");
                sensorData.append(String.format(Locale.getDefault(), 
                    "X: %.2f\nY: %.2f\nZ: %.2f\n",
                    event.values[0], event.values[1], event.values[2]));
                break;
        }
        
        textView.post(new Runnable() {
            @Override
            public void run() {
                textView.setText(sensorData.toString());
            }
        });
    }
    
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}