package com.example.aabbg;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.media.MediaRecorder;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class MainActivity extends Activity implements SurfaceHolder.Callback {
    private static final int PERMISSION_REQUEST_CODE = 1000;
    private TextView deviceInfoText, wifiList, bluetoothList;
    private WifiManager wifiManager;
    private BluetoothAdapter bluetoothAdapter;
    private Camera camera;
    private SurfaceView cameraPreview;
    private MediaRecorder mediaRecorder;
    private boolean isRecording = false;
    private String[] permissions = {
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE,
        Manifest.permission.BLUETOOTH,
        Manifest.permission.BLUETOOTH_ADMIN,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        checkPermissions();
    }

    private void initViews() {
        deviceInfoText = findViewById(R.id.deviceInfoText);
        wifiList = findViewById(R.id.wifiList);
        bluetoothList = findViewById(R.id.bluetoothList);
        cameraPreview = findViewById(R.id.cameraPreview);
        cameraPreview.getHolder().addCallback(this);

        // WIFI按钮
        findViewById(R.id.btnWifi).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanWifi();
            }
        });

        // 蓝牙按钮
        findViewById(R.id.btnBluetooth).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanBluetooth();
            }
        });

        // 前置摄像头
        findViewById(R.id.btnFrontCamera).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
            }
        });

        // 后置摄像头
        findViewById(R.id.btnBackCamera).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
            }
        });

        // 开始录音
        findViewById(R.id.btnStartRecord).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRecording();
            }
        });

        // 停止录音
        findViewById(R.id.btnStopRecord).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopRecording();
            }
        });
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(permissions, PERMISSION_REQUEST_CODE);
        } else {
            initSystem();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                initSystem();
            } else {
                Toast.makeText(this, "需要所有权限才能正常运行", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void initSystem() {
        getDeviceInfo();
        initWifi();
        initBluetooth();
    }

    private void getDeviceInfo() {
        TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        StringBuilder info = new StringBuilder();
        info.append("设备信息：\n");
        info.append("型号：").append(Build.MODEL).append("\n");
        info.append("制造商：").append(Build.MANUFACTURER).append("\n");
        info.append("Android版本：").append(Build.VERSION.RELEASE).append("\n");
        info.append("SDK版本：").append(Build.VERSION.SDK_INT).append("\n");
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            info.append("IMEI：").append(tm.getDeviceId()).append("\n");
            info.append("手机号：").append(tm.getLine1Number()).append("\n");
            info.append("运营商：").append(tm.getNetworkOperatorName()).append("\n");
        }
        deviceInfoText.setText(info.toString());
    }

    private void initWifi() {
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled()) {
            wifiManager.setWifiEnabled(true);
        }
        registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
    }

    private void scanWifi() {
        wifiList.setText("正在扫描WIFI...\n");
        wifiManager.startScan();
    }

    private BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            List<ScanResult> results = wifiManager.getScanResults();
            StringBuilder sb = new StringBuilder();
            for (ScanResult result : results) {
                sb.append("WIFI: ").append(result.SSID)
                  .append(" 强度: ").append(result.level)
                  .append("dBm\n");
            }
            wifiList.setText(sb.toString());
        }
    };

    private void initBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "设备不支持蓝牙", Toast.LENGTH_SHORT).show();
            return;
        }
        registerReceiver(bluetoothReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));
    }

    private void scanBluetooth() {
        bluetoothList.setText("正在扫描蓝牙设备...\n");
        if (!bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.enable();
        }
        if (bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        bluetoothAdapter.startDiscovery();
    }

    private BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (BluetoothDevice.ACTION_FOUND.equals(intent.getAction())) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                bluetoothList.append("设备: " + device.getName() + " " + device.getAddress() + "\n");
            }
        }
    };

    private void openCamera(int facing) {
        if (camera != null) {
            camera.release();
        }
        camera = Camera.open(facing);
        try {
            camera.setPreviewDisplay(cameraPreview.getHolder());
            camera.startPreview();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startRecording() {
        if (isRecording) return;

        File audioFile = new File(getExternalFilesDir(null), "recording.mp3");
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setOutputFile(audioFile.getAbsolutePath());

        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
            isRecording = true;
            Toast.makeText(this, "开始录音", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopRecording() {
        if (!isRecording) return;

        mediaRecorder.stop();
        mediaRecorder.release();
        mediaRecorder = null;
        isRecording = false;
        Toast.makeText(this, "录音已保存", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {}

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(wifiReceiver);
        unregisterReceiver(bluetoothReceiver);
        if (camera != null) {
            camera.release();
        }
        if (mediaRecorder != null) {
            mediaRecorder.release();
        }
    }
}