package com.example.aabbg.handlers;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;
import android.widget.TextView;

public class SensorHandler implements SensorEventListener {
    private TextView txtSensorData;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    
    // 用于平滑处理的变量
    private float[] lastAccel = new float[3];
    private float[] lastGyro = new float[3];
    private static final float ALPHA = 0.8f; // 平滑因子
    private long lastUpdate = 0;
    private static final long REFRESH_INTERVAL = 500; // 500毫秒更新一次UI

    public SensorHandler(Context context, TextView txtSensorData) {
        this.txtSensorData = txtSensorData;
        
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        }
    }

    public void startSensorMonitoring() {
        if (sensorManager != null) {
            if (accelerometer != null) {
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            }
            if (gyroscope != null) {
                sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
            }
        }
    }

    public void stopSensorMonitoring() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        long currentTime = System.currentTimeMillis();
        
        // 使用低通滤波器平滑数据
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            lastAccel[0] = ALPHA * lastAccel[0] + (1 - ALPHA) * event.values[0];
            lastAccel[1] = ALPHA * lastAccel[1] + (1 - ALPHA) * event.values[1];
            lastAccel[2] = ALPHA * lastAccel[2] + (1 - ALPHA) * event.values[2];
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            lastGyro[0] = ALPHA * lastGyro[0] + (1 - ALPHA) * event.values[0];
            lastGyro[1] = ALPHA * lastGyro[1] + (1 - ALPHA) * event.values[1];
            lastGyro[2] = ALPHA * lastGyro[2] + (1 - ALPHA) * event.values[2];
        }

        // 限制更新频率
        if (currentTime - lastUpdate > REFRESH_INTERVAL) {
            lastUpdate = currentTime;
            
            StringBuilder info = new StringBuilder();
            info.append("传感器数据:\n\n");
            
            // 加速度计数据
            info.append("加速度计 (m/s²):\n");
            info.append(String.format("X: %.2f\n", lastAccel[0]));
            info.append(String.format("Y: %.2f\n", lastAccel[1]));
            info.append(String.format("Z: %.2f\n\n", lastAccel[2]));
            
            // 陀螺仪数据
            info.append("陀螺仪 (rad/s):\n");
            info.append(String.format("X: %.2f\n", lastGyro[0]));
            info.append(String.format("Y: %.2f\n", lastGyro[1]));
            info.append(String.format("Z: %.2f", lastGyro[2]));
            
            txtSensorData.setText(info.toString());
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 精度变化时的处理
    }
}