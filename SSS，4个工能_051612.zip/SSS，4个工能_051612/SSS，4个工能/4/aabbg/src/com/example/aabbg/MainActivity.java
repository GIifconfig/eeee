package com.example.aabbg;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.media.MediaPlayer.OnCompletionListener;

import com.example.aabbg.handlers.*;
import com.example.aabbg.utils.PermissionUtil;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SurfaceHolder.Callback {
    private TextView txtLocation;
    private TextView txtSystemInfo;
    private TextView txtSensorData;
    private TextView txtWifiResults;
    private TextView txtBluetoothResults;
    private TextView txtRecordStatus;
    private SurfaceView surfaceView;

    private LocationHandler locationHandler;
    private SensorHandler sensorHandler;
    private WifiHandler wifiHandler;
    private BluetoothHandler bluetoothHandler;
    private CameraHandler cameraHandler;

    private MediaRecorder mediaRecorder;
    private MediaPlayer mediaPlayer;
    private String audioFilePath;
    private boolean isRecording = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (PermissionUtil.checkPermissions(this)) {
            initViews();
            initHandlers();
            setupAudioPath();
        }
    }

    private void initViews() {
        txtLocation = findViewById(R.id.txtLocation);
        txtSystemInfo = findViewById(R.id.txtSystemInfo);
        txtSensorData = findViewById(R.id.txtSensorData);
        txtWifiResults = findViewById(R.id.txtWifiResults);
        txtBluetoothResults = findViewById(R.id.txtBluetoothResults);
        txtRecordStatus = findViewById(R.id.txtRecordStatus);
        surfaceView = findViewById(R.id.surfaceView);
        surfaceView.getHolder().addCallback(this);

        findViewById(R.id.btnGetLocation).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                locationHandler.startLocationUpdates();
            }
        });

        findViewById(R.id.btnRefreshInfo).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshSystemInfo();
            }
        });

        findViewById(R.id.btnWifiScan).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                wifiHandler.startWifiScan();
            }
        });

        findViewById(R.id.btnBluetoothScan).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                bluetoothHandler.startBluetoothScan();
            }
        });

        findViewById(R.id.btnSwitchFront).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraHandler.openCamera(true, surfaceView.getHolder());
            }
        });

        findViewById(R.id.btnSwitchBack).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraHandler.openCamera(false, surfaceView.getHolder());
            }
        });

        findViewById(R.id.btnStartRecord).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                startRecording();
            }
        });

        findViewById(R.id.btnStopRecord).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                stopRecording();
            }
        });

        findViewById(R.id.btnPlayRecord).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                playRecording();
            }
        });

        // 相机控制按钮
        findViewById(R.id.btnZoomIn).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraHandler.zoomIn();
            }
        });

        findViewById(R.id.btnZoomOut).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraHandler.zoomOut();
            }
        });

        findViewById(R.id.btnFlash).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraHandler.toggleFlash();
            }
        });

        // 亮度控制
        SeekBar brightnessSeekBar = findViewById(R.id.brightnessSeekBar);
        brightnessSeekBar.setProgress(getScreenBrightness());
        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    setScreenBrightness(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void initHandlers() {
        locationHandler = new LocationHandler(this, txtLocation);
        sensorHandler = new SensorHandler(this, txtSensorData);
        wifiHandler = new WifiHandler(this, txtWifiResults);
        bluetoothHandler = new BluetoothHandler(this, txtBluetoothResults);
        cameraHandler = new CameraHandler(this);
    }

    private void setupAudioPath() {
        audioFilePath = new File(getExternalFilesDir(null),
            "record_" + getCurrentTimeString() + ".mp3").getAbsolutePath();
    }

    private void refreshSystemInfo() {
        StringBuilder info = new StringBuilder();
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        try {
            info.append("===== 系统信息 =====\n");
            info.append("制造商: ").append(android.os.Build.MANUFACTURER).append("\n");
            info.append("型号: ").append(android.os.Build.MODEL).append("\n");
            info.append("Android版本: ").append(android.os.Build.VERSION.RELEASE).append("\n");
            info.append("API级别: ").append(android.os.Build.VERSION.SDK_INT).append("\n\n");

            info.append("===== 网络信息 =====\n");
            if (tm != null) {
                if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE)
                    == PackageManager.PERMISSION_GRANTED) {
                    info.append("运营商: ").append(tm.getNetworkOperatorName()).append("\n");
                    info.append("网络类型: ").append(getNetworkType(tm.getNetworkType())).append("\n");
                    info.append("SIM卡状态: ").append(getSimState(tm.getSimState())).append("\n");
                } else {
                    info.append("需要READ_PHONE_STATE权限\n");
                }
            }

            txtSystemInfo.setText(info.toString());
        } catch (SecurityException e) {
            Toast.makeText(this, "需要系统权限", Toast.LENGTH_SHORT).show();
        }
    }

    private String getNetworkType(int type) {
        switch (type) {
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_CDMA:
            case TelephonyManager.NETWORK_TYPE_1xRTT:
            case TelephonyManager.NETWORK_TYPE_IDEN:
                return "2G";
            case TelephonyManager.NETWORK_TYPE_UMTS:
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
            case TelephonyManager.NETWORK_TYPE_EHRPD:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                return "3G";
            case TelephonyManager.NETWORK_TYPE_LTE:
                return "4G";
            case 20:  // TelephonyManager.NETWORK_TYPE_NR in Android 11+
                return "5G";
            default:
                return "未知";
        }
    }

    private String getSimState(int state) {
        switch (state) {
            case TelephonyManager.SIM_STATE_ABSENT:
                return "无SIM卡";
            case TelephonyManager.SIM_STATE_NETWORK_LOCKED:
                return "需要网络PIN解锁";
            case TelephonyManager.SIM_STATE_PIN_REQUIRED:
                return "需要SIM卡PIN解锁";
            case TelephonyManager.SIM_STATE_PUK_REQUIRED:
                return "需要SIM卡PUK解锁";
            case TelephonyManager.SIM_STATE_READY:
                return "就绪";
            case TelephonyManager.SIM_STATE_UNKNOWN:
                return "未知状态";
            default:
                return "状态码: " + state;
        }
    }

    private void startRecording() {
        if (isRecording) {
            Toast.makeText(this, "正在录音中", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setOutputFile(audioFilePath);
            mediaRecorder.prepare();
            mediaRecorder.start();
            
            isRecording = true;
            txtRecordStatus.setText("录音中...");
            Toast.makeText(this, "开始录音", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "录音失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void stopRecording() {
        if (!isRecording) {
            return;
        }

        try {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
            isRecording = false;
            txtRecordStatus.setText("录音已保存: " + audioFilePath);
            Toast.makeText(this, "录音已保存", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "停止录音失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void playRecording() {
        if (isRecording) {
            Toast.makeText(this, "请先停止录音", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(audioFilePath);
            mediaPlayer.prepare();
            mediaPlayer.start();
            
            mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();
                    Toast.makeText(MainActivity.this, "播放完成", Toast.LENGTH_SHORT).show();
                }
            });
            
            txtRecordStatus.setText("正在播放录音...");
        } catch (IOException e) {
            Toast.makeText(this, "播放失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private String getCurrentTimeString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private int getScreenBrightness() {
        try {
            return Settings.System.getInt(getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException e) {
            return 128;
        }
    }

    private void setScreenBrightness(int brightness) {
        if (checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SETTINGS)
            == PackageManager.PERMISSION_GRANTED) {
            Settings.System.putInt(getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, brightness);
            
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = brightness / 255f;
            getWindow().setAttributes(params);
        } else {
            Toast.makeText(this, "需要修改系统设置权限", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (PermissionUtil.hasPermissions(this)) {
            cameraHandler.openCamera(false, holder);
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        cameraHandler.releaseCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (PermissionUtil.hasPermissions(this)) {
            sensorHandler.startSensorMonitoring();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorHandler.stopSensorMonitoring();
        if (isRecording) {
            stopRecording();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationHandler.stopLocationUpdates();
        wifiHandler.stopWifiScan();
        bluetoothHandler.stopBluetoothScan();
        cameraHandler.releaseCamera();
        
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PermissionUtil.PERMISSION_REQUEST_CODE) {
            if (PermissionUtil.isAllPermissionsGranted(grantResults)) {
                initViews();
                initHandlers();
                setupAudioPath();
            } else {
                Toast.makeText(this, "需要相关权限才能正常运行", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
}