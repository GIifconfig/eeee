package com.example.aabbg.handlers;

import android.content.Context;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

@SuppressWarnings("deprecation")
public class CameraHandler {
    private Context context;
    private Camera camera;
    private boolean isFlashOn = false;
    private int currentZoom = 0;
    private int maxZoom = 0;

    public CameraHandler(Context context) {
        this.context = context;
    }

    public void openCamera(boolean frontCamera, SurfaceHolder holder) {
        releaseCamera();
        try {
            camera = Camera.open(frontCamera ? 1 : 0);
            camera.setPreviewDisplay(holder);
            
            Camera.Parameters parameters = camera.getParameters();
            
            if (parameters.isZoomSupported()) {
                maxZoom = parameters.getMaxZoom();
            }
            
            List<String> focusModes = parameters.getSupportedFocusModes();
            if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            }
            
            camera.setParameters(parameters);
            camera.startPreview();
        } catch (IOException e) {
            Toast.makeText(context, "打开相机失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void toggleFlash() {
        if (camera == null) {
            return;
        }

        try {
            Camera.Parameters parameters = camera.getParameters();
            if (parameters.getFlashMode() == null) {
                Toast.makeText(context, "该设备不支持闪光灯", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isFlashOn) {
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                isFlashOn = true;
                Toast.makeText(context, "闪光灯已开启", Toast.LENGTH_SHORT).show();
            } else {
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                isFlashOn = false;
                Toast.makeText(context, "闪光灯已关闭", Toast.LENGTH_SHORT).show();
            }
            
            camera.setParameters(parameters);
        } catch (Exception e) {
            Toast.makeText(context, "闪光灯控制失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void zoomIn() {
        if (camera == null) {
            return;
        }

        try {
            Camera.Parameters parameters = camera.getParameters();
            if (!parameters.isZoomSupported()) {
                Toast.makeText(context, "该设备不支持变焦", Toast.LENGTH_SHORT).show();
                return;
            }

            if (currentZoom < maxZoom) {
                currentZoom = Math.min(currentZoom + maxZoom/10, maxZoom);
                parameters.setZoom(currentZoom);
                camera.setParameters(parameters);
            } else {
                Toast.makeText(context, "已达到最大变焦", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(context, "变焦失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void zoomOut() {
        if (camera == null) {
            return;
        }

        try {
            Camera.Parameters parameters = camera.getParameters();
            if (!parameters.isZoomSupported()) {
                Toast.makeText(context, "该设备不支持变焦", Toast.LENGTH_SHORT).show();
                return;
            }

            if (currentZoom > 0) {
                currentZoom = Math.max(currentZoom - maxZoom/10, 0);
                parameters.setZoom(currentZoom);
                camera.setParameters(parameters);
            } else {
                Toast.makeText(context, "已达到最小变焦", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(context, "变焦失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void releaseCamera() {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
            isFlashOn = false;
            currentZoom = 0;
        }
    }
}