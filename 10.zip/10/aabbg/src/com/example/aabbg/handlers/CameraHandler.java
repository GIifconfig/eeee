package com.example.aabbg.handlers;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class CameraHandler {
    private static final String TAG = "CameraHandler";
    private Context context;
    private CameraManager cameraManager;
    private String frontCameraId;
    private String backCameraId;
    private CameraDevice frontCamera;
    private CameraDevice backCamera;
    private CameraCaptureSession frontSession;
    private CameraCaptureSession backSession;
    private ImageReader frontImageReader;
    private ImageReader backImageReader;
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;
    private boolean isFlashOn = false;
    
    private float frontCurrentZoom = 1.0f;
    private float backCurrentZoom = 1.0f;
    private float frontMaxZoom = 1.0f;
    private float backMaxZoom = 1.0f;
    private Rect frontSensorSize;
    private Rect backSensorSize;
    private Surface frontPreviewSurface;
    private Surface backPreviewSurface;
    private boolean hasFlash = false;
    
    private static final int IMAGE_WIDTH = 1920;
    private static final int IMAGE_HEIGHT = 1080;
    private static final String SAVE_PATH = "/storage/emulated/0/11/";
    private final Semaphore cameraOpenCloseLock = new Semaphore(1);

    private boolean isCameraInitialized = false;
    private SurfaceHolder cachedFrontHolder;
    private SurfaceHolder cachedBackHolder;

    private CaptureRequest.Builder backPreviewBuilder;
    private CaptureRequest mPreviewRequest;

    public CameraHandler(Context context) {
        this.context = context;
        this.cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        createSaveDirectory();
        startBackgroundThread();
        findCameraIds();
        setupImageReaders();
    }

    private void findCameraIds() {
        try {
            String[] cameraIds = cameraManager.getCameraIdList();
            for (String cameraId : cameraIds) {
                CameraCharacteristics characteristics = 
                    cameraManager.getCameraCharacteristics(cameraId);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                if (facing != null) {
                    if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                        frontCameraId = cameraId;
                    } else if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                        backCameraId = cameraId;
                        Boolean flashAvailable = characteristics.get(
                            CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        hasFlash = flashAvailable != null && flashAvailable;
                    }
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "查找相机ID失败", e);
        }
    }

    private void setupImageReaders() {
        frontImageReader = ImageReader.newInstance(IMAGE_WIDTH, IMAGE_HEIGHT, 
            ImageFormat.JPEG, 2);
        backImageReader = ImageReader.newInstance(IMAGE_WIDTH, IMAGE_HEIGHT, 
            ImageFormat.JPEG, 2);

        ImageReader.OnImageAvailableListener imageListener = new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                final Image image = reader.acquireNextImage();
                if (image != null) {
                    backgroundHandler.post(new ImageSaver(image, reader == frontImageReader));
                }
            }
        };

        frontImageReader.setOnImageAvailableListener(imageListener, backgroundHandler);
        backImageReader.setOnImageAvailableListener(imageListener, backgroundHandler);
    }

    private class ImageSaver implements Runnable {
        private final Image image;
        private final boolean isFront;

        ImageSaver(Image image, boolean isFront) {
            this.image = image;
            this.isFront = isFront;
        }

        @Override
        public void run() {
            if (image == null) return;
            
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.capacity()];
            buffer.get(bytes);
            save(bytes, isFront);
            image.close();
        }
    }

    private void createSaveDirectory() {
        File directory = new File(SAVE_PATH);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "停止后台线程失败", e);
            }
        }
    }

    public void startBothCameras(final SurfaceHolder frontHolder, final SurfaceHolder backHolder) {
        cachedFrontHolder = frontHolder;
        cachedBackHolder = backHolder;
        initializeCameras();
    }

    private void initializeCameras() {
        if (isCameraInitialized) {
            releaseCamera();
        }

        try {
            if (frontCameraId != null && cachedFrontHolder != null) {
                frontPreviewSurface = cachedFrontHolder.getSurface();
                CameraCharacteristics characteristics = 
                    cameraManager.getCameraCharacteristics(frontCameraId);
                frontSensorSize = characteristics.get(
                    CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                Float maxZoom = characteristics.get(
                    CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                if (maxZoom != null) {
                    frontMaxZoom = maxZoom;
                }
                setupCamera(frontCameraId, cachedFrontHolder, true);
            }
            
            if (backCameraId != null && cachedBackHolder != null) {
                backPreviewSurface = cachedBackHolder.getSurface();
                CameraCharacteristics characteristics = 
                    cameraManager.getCameraCharacteristics(backCameraId);
                backSensorSize = characteristics.get(
                    CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                Float maxZoom = characteristics.get(
                    CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                if (maxZoom != null) {
                    backMaxZoom = maxZoom;
                }
                setupCamera(backCameraId, cachedBackHolder, false);
            }

            isCameraInitialized = true;
        } catch (CameraAccessException e) {
            Log.e(TAG, "初始化相机失败", e);
            Toast.makeText(context, "相机初始化失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void setupCamera(final String cameraId, final SurfaceHolder holder, 
            final boolean isFront) {
        try {
            if (!cameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                throw new RuntimeException("相机打开超时");
            }

            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    cameraOpenCloseLock.release();
                    if (isFront) {
                        frontCamera = camera;
                    } else {
                        backCamera = camera;
                    }
                    createCameraPreviewSession(camera, holder, isFront);
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    cameraOpenCloseLock.release();
                    camera.close();
                    if (isFront) {
                        frontCamera = null;
                    } else {
                        backCamera = null;
                    }
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    cameraOpenCloseLock.release();
                    camera.close();
                    if (isFront) {
                        frontCamera = null;
                    } else {
                        backCamera = null;
                    }
                    String errorMsg = "相机错误: ";
                    switch (error) {
                        case ERROR_CAMERA_DEVICE:
                            errorMsg += "设备错误";
                            break;
                        case ERROR_CAMERA_DISABLED:
                            errorMsg += "设备被禁用";
                            break;
                        case ERROR_CAMERA_IN_USE:
                            errorMsg += "设备正在使用";
                            break;
                        case ERROR_CAMERA_SERVICE:
                            errorMsg += "服务错误";
                            break;
                        case ERROR_MAX_CAMERAS_IN_USE:
                            errorMsg += "达到最大相机使用数";
                            break;
                        default:
                            errorMsg += "未知错误: " + error;
                    }
                    Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show();
                }
            }, backgroundHandler);
        } catch (CameraAccessException | InterruptedException | SecurityException e) {
            Log.e(TAG, "设置相机失败", e);
            cameraOpenCloseLock.release();
            Toast.makeText(context, "相机访问错误: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void createCameraPreviewSession(final CameraDevice camera, SurfaceHolder holder, 
            final boolean isFront) {
        try {
            final Surface previewSurface = holder.getSurface();
            List<Surface> surfaces = new ArrayList<>();
            surfaces.add(previewSurface);
            
            final ImageReader imageReader = isFront ? frontImageReader : backImageReader;
            surfaces.add(imageReader.getSurface());

            final CaptureRequest.Builder previewRequestBuilder = 
                camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            previewRequestBuilder.addTarget(previewSurface);

            if (!isFront) {
                backPreviewBuilder = previewRequestBuilder;
                if (hasFlash && isFlashOn) {
                    backPreviewBuilder.set(CaptureRequest.FLASH_MODE, 
                        CaptureRequest.FLASH_MODE_TORCH);
                }
            }

            camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    try {
                        if (isFront) {
                            frontSession = session;
                        } else {
                            backSession = session;
                        }

                        previewRequestBuilder.set(CaptureRequest.CONTROL_MODE,
                            CaptureRequest.CONTROL_MODE_AUTO);
                        
                        final Rect sensorSize = isFront ? frontSensorSize : backSensorSize;
                        final float currentZoom = isFront ? frontCurrentZoom : backCurrentZoom;
                        
                        if (sensorSize != null) {
                            previewRequestBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                                getZoomRect(sensorSize, currentZoom));
                        }
                        
                        mPreviewRequest = previewRequestBuilder.build();
                        session.setRepeatingRequest(mPreviewRequest, null, backgroundHandler);
                    } catch (CameraAccessException e) {
                        Log.e(TAG, "设置预览失败", e);
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    Toast.makeText(context, "创建相机预览失败", 
                        Toast.LENGTH_SHORT).show();
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "创建预览会话失败", e);
        }
    }

    private void updatePreview() {
        if (backCamera == null || backSession == null) return;

        try {
            if (hasFlash) {
                backPreviewBuilder.set(CaptureRequest.FLASH_MODE,
                    isFlashOn ? CaptureRequest.FLASH_MODE_TORCH : 
                               CaptureRequest.FLASH_MODE_OFF);
            }
            mPreviewRequest = backPreviewBuilder.build();
            backSession.setRepeatingRequest(mPreviewRequest, null, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "更新预览失败", e);
        }
    }

    public void setFrontZoom(float zoom) {
        if (frontCamera == null || frontSensorSize == null || frontSession == null) {
            Toast.makeText(context, "前置相机未就绪", Toast.LENGTH_SHORT).show();
            return;
        }
        
        frontCurrentZoom = Math.max(1.0f, Math.min(zoom, frontMaxZoom));
        updateZoom(true);
    }

    public void setBackZoom(float zoom) {
        if (backCamera == null || backSensorSize == null || backSession == null) {
            Toast.makeText(context, "后置相机未就绪", Toast.LENGTH_SHORT).show();
            return;
        }
        
        backCurrentZoom = Math.max(1.0f, Math.min(zoom, backMaxZoom));
        updateZoom(false);
    }

    private void updateZoom(final boolean isFront) {
        try {
            final CameraDevice camera = isFront ? frontCamera : backCamera;
            final CameraCaptureSession session = isFront ? frontSession : backSession;
            final Rect sensorSize = isFront ? frontSensorSize : backSensorSize;
            final float currentZoom = isFront ? frontCurrentZoom : backCurrentZoom;
            final Surface previewSurface = isFront ? frontPreviewSurface : backPreviewSurface;
            
            if (camera == null || session == null || sensorSize == null || 
                    previewSurface == null) {
                Toast.makeText(context, 
                    (isFront ? "前置" : "后置") + "相机未就绪", 
                    Toast.LENGTH_SHORT).show();
                return;
            }

            CaptureRequest.Builder builder = camera.createCaptureRequest(
                CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(previewSurface);
            
            Rect zoomRect = getZoomRect(sensorSize, currentZoom);
            builder.set(CaptureRequest.SCALER_CROP_REGION, zoomRect);

            if (!isFront && hasFlash) {
                builder.set(CaptureRequest.FLASH_MODE,
                    isFlashOn ? CaptureRequest.FLASH_MODE_TORCH : 
                               CaptureRequest.FLASH_MODE_OFF);
            }
            
            session.setRepeatingRequest(builder.build(), null, backgroundHandler);
            
            Toast.makeText(context, String.format(Locale.getDefault(), 
                "%s摄像头变焦: %.1f", isFront ? "前置" : "后置", currentZoom), 
                Toast.LENGTH_SHORT).show();
        } catch (CameraAccessException e) {
            Log.e(TAG, "设置变焦失败", e);
            Toast.makeText(context, "设置变焦失败", Toast.LENGTH_SHORT).show();
        }
    }

    private Rect getZoomRect(Rect sensorSize, float zoomLevel) {
        int centerX = sensorSize.width() / 2;
        int centerY = sensorSize.height() / 2;
        int deltaX = (int)((0.5f * sensorSize.width()) / zoomLevel);
        int deltaY = (int)((0.5f * sensorSize.height()) / zoomLevel);
        
        return new Rect(
            centerX - deltaX,
            centerY - deltaY,
            centerX + deltaX,
            centerY + deltaY
        );
    }

    public void takeFrontPhoto() {
        if (frontCamera == null) {
            Toast.makeText(context, "前置相机未就绪", Toast.LENGTH_SHORT).show();
            return;
        }
        takePicture(frontCamera, true);
    }

    public void takeBackPhoto() {
        if (backCamera == null) {
            Toast.makeText(context, "后置相机未就绪", Toast.LENGTH_SHORT).show();
            return;
        }
        takePicture(backCamera, false);
    }

    public void takeBothPhotos() {
        if (frontCamera != null) {
            takePicture(frontCamera, true);
        } else {
            Toast.makeText(context, "前置相机未就绪", Toast.LENGTH_SHORT).show();
        }
        
        if (backCamera != null) {
            takePicture(backCamera, false);
        } else {
            Toast.makeText(context, "后置相机未就绪", Toast.LENGTH_SHORT).show();
        }
    }

    private void takePicture(final CameraDevice camera, final boolean isFront) {
        try {
            final ImageReader reader = isFront ? frontImageReader : backImageReader;
            final Surface previewSurface = isFront ? frontPreviewSurface : backPreviewSurface;
            final CameraCaptureSession captureSession = isFront ? frontSession : backSession;
            final Rect sensorSize = isFront ? frontSensorSize : backSensorSize;
            final float currentZoom = isFront ? frontCurrentZoom : backCurrentZoom;

            if (camera == null || captureSession == null || reader == null || 
                previewSurface == null || sensorSize == null) {
                Toast.makeText(context, 
                    (isFront ? "前置" : "后置") + "相机未就绪", 
                    Toast.LENGTH_SHORT).show();
                return;
            }

            // 拍照请求
            final CaptureRequest.Builder captureBuilder = 
                camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(reader.getSurface());
            
            // 设置基本参数
            captureBuilder.set(CaptureRequest.CONTROL_MODE,
                CaptureRequest.CONTROL_MODE_AUTO);
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            
            // 设置闪光灯
            if (!isFront && hasFlash) {
                captureBuilder.set(CaptureRequest.FLASH_MODE,
                    isFlashOn ? CaptureRequest.FLASH_MODE_TORCH : 
                               CaptureRequest.FLASH_MODE_OFF);
            }

            // 设置变焦
            captureBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                getZoomRect(sensorSize, currentZoom));

            // 拍照
            captureSession.stopRepeating();
            captureSession.capture(captureBuilder.build(), 
                new CameraCaptureSession.CaptureCallback() {
                    @Override
                    public void onCaptureCompleted(CameraCaptureSession session,
                            CaptureRequest request, TotalCaptureResult result) {
                        try {
                            // 恢复预览
                            final CaptureRequest.Builder previewBuilder = 
                                camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                            previewBuilder.addTarget(previewSurface);
                            previewBuilder.set(CaptureRequest.SCALER_CROP_REGION,
                                getZoomRect(sensorSize, currentZoom));
                            
                            if (!isFront && hasFlash) {
                                previewBuilder.set(CaptureRequest.FLASH_MODE,
                                    isFlashOn ? CaptureRequest.FLASH_MODE_TORCH : 
                                               CaptureRequest.FLASH_MODE_OFF);
                            }
                            
                            session.setRepeatingRequest(previewBuilder.build(), 
                                null, backgroundHandler);
                        } catch (CameraAccessException e) {
                            Log.e(TAG, "恢复预览失败", e);
                        }
                    }

                    @Override
                    public void onCaptureFailed(CameraCaptureSession session,
                            CaptureRequest request, CaptureFailure failure) {
                        String reason = "";
                        switch (failure.getReason()) {
                            case CaptureFailure.REASON_ERROR:
                                reason = "发生错误";
                                break;
                            case CaptureFailure.REASON_FLUSHED:
                                reason = "请求被取消";
                                break;
                            default:
                                reason = "未知原因";
                        }
                        Toast.makeText(context, "拍照失败: " + reason, 
                            Toast.LENGTH_SHORT).show();
                    }
                }, 
                backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "拍照失败", e);
            Toast.makeText(context, "拍照失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    private void save(byte[] bytes, boolean isFront) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", 
            Locale.getDefault()).format(new Date());
        String filename = (isFront ? "front_" : "back_") + timestamp + ".jpg";
        File file = new File(SAVE_PATH + filename);
        
        try (FileOutputStream output = new FileOutputStream(file)) {
            output.write(bytes);
            Toast.makeText(context, "照片已保存: " + file.getPath(), 
                Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Log.e(TAG, "保存照片失败", e);
            Toast.makeText(context, "保存照片失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    public void toggleFlash() {
        if (!hasFlash) {
            Toast.makeText(context, "此设备不支持闪光灯", Toast.LENGTH_SHORT).show();
            return;
        }

        if (backCamera == null || backSession == null) {
            Toast.makeText(context, "后置相机未就绪", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            isFlashOn = !isFlashOn;
            updatePreview();
            Toast.makeText(context, isFlashOn ? "闪光灯已开启" : "闪光灯已关闭", 
                Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "闪光灯控制失败", e);
            Toast.makeText(context, "闪光灯控制失败: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    public void releaseCamera() {
        try {
            isCameraInitialized = false;
            cameraOpenCloseLock.acquire();
            
            if (frontSession != null) {
                frontSession.close();
                frontSession = null;
            }
            if (backSession != null) {
                backSession.close();
                backSession = null;
            }
            if (frontCamera != null) {
                frontCamera.close();
                frontCamera = null;
            }
            if (backCamera != null) {
                backCamera.close();
                backCamera = null;
            }
            if (frontImageReader != null) {
                frontImageReader.close();
                frontImageReader = null;
            }
            if (backImageReader != null) {
                backImageReader.close();
                backImageReader = null;
            }
            
            if (backgroundThread != null) {
                backgroundThread.quitSafely();
                try {
                    backgroundThread.join();
                    backgroundThread = null;
                    backgroundHandler = null;
                } catch (InterruptedException e) {
                    Log.e(TAG, "停止后台线程失败", e);
                }
            }
        } catch (InterruptedException e) {
            Log.e(TAG, "相机关闭中断", e);
            throw new RuntimeException("相机关闭中断", e);
        } finally {
            cameraOpenCloseLock.release();
        }
    }

    public void onResume() {
        startBackgroundThread();
        setupImageReaders();
        if (cachedFrontHolder != null || cachedBackHolder != null) {
            initializeCameras();
        }
    }

    public void onPause() {
        releaseCamera();
    }
}