package com.example.aabbg.handlers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;

public class WifiHandler {
    private final Context context;
    private final WifiManager wifiManager;
    private final TextView txtWifiResults;
    private final BroadcastReceiver wifiReceiver;
    private boolean isScanning = false;

    public WifiHandler(Context context, TextView txtWifiResults) {
        this.context = context;
        this.txtWifiResults = txtWifiResults;
        this.wifiManager = (WifiManager) 
            context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        
        this.wifiReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(intent.getAction())) {
                    boolean success = intent.getBooleanExtra(
                        WifiManager.EXTRA_RESULTS_UPDATED, false);
                    if (success) {
                        updateWifiResults();
                    } else {
                        showToast("WiFi扫描失败，使用缓存结果");
                        updateWifiResults(); // 使用缓存结果
                    }
                    isScanning = false;
                }
            }
        };
    }

    private void showToast(final String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public void startWifiScan() {
        if (isScanning) {
            showToast("正在扫描中，请稍候...");
            return;
        }

        if (!wifiManager.isWifiEnabled()) {
            showToast("正在开启WIFI...");
            wifiManager.setWifiEnabled(true);
        }

        txtWifiResults.setText("正在扫描WIFI...\n请稍候...");
        
        try {
            context.registerReceiver(wifiReceiver, 
                new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
            
            isScanning = true;
            if (!wifiManager.startScan()) {
                showToast("启动扫描失败，使用缓存结果");
                updateWifiResults();
                isScanning = false;
            }
        } catch (Exception e) {
            showToast("扫描出错: " + e.getMessage());
            isScanning = false;
        }
    }

    private void updateWifiResults() {
        List<ScanResult> results = wifiManager.getScanResults();
        if (results == null) {
            results = new ArrayList<>();
        }

        // 按信号强度排序
        Collections.sort(results, new Comparator<ScanResult>() {
            @Override
            public int compare(ScanResult result1, ScanResult result2) {
                return result2.level - result1.level;
            }
        });

        StringBuilder sb = new StringBuilder();
        sb.append("发现 ").append(results.size()).append(" 个WIFI网络：\n\n");
        
        for (ScanResult result : results) {
            // 计算信号强度等级 (0-4)
            int level = WifiManager.calculateSignalLevel(result.level, 5);
            
            // 获取加密类型
            String security = getSecurityType(result);
            
            // 获取频段
            String band = result.frequency > 5000 ? "5GHz" : "2.4GHz";
            
            // 获取信道
            int channel = getChannel(result.frequency);
            
            sb.append("名称: ").append(result.SSID.isEmpty() ? "<隐藏>" : result.SSID)
              .append("\n信号强度: ").append(result.level).append(" dBm")
              .append(" (").append(getSignalStrength(level)).append(")")
              .append("\n频率: ").append(result.frequency).append(" MHz")
              .append(" (").append(band).append(", CH").append(channel).append(")")
              .append("\n加密类型: ").append(security)
              .append("\nMAC地址: ").append(result.BSSID);

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                sb.append("\n运营商: ").append(result.venueName != null ? 
                    result.venueName : "未知");
            }
            
            sb.append("\n\n");
        }
        
        txtWifiResults.setText(sb.toString());
    }

    private String getSecurityType(ScanResult scanResult) {
        String capabilities = scanResult.capabilities;
        if (capabilities.contains("WEP")) {
            return "WEP";
        } else if (capabilities.contains("WPA3")) {
            return "WPA3";
        } else if (capabilities.contains("WPA2")) {
            if (capabilities.contains("PSK")) {
                return "WPA2-Personal";
            } else if (capabilities.contains("EAP")) {
                return "WPA2-Enterprise";
            }
            return "WPA2";
        } else if (capabilities.contains("WPA")) {
            if (capabilities.contains("PSK")) {
                return "WPA-Personal";
            } else if (capabilities.contains("EAP")) {
                return "WPA-Enterprise";
            }
            return "WPA";
        } else {
            return "开放";
        }
    }

    private String getSignalStrength(int level) {
        switch (level) {
            case 4: return "极好 ★★★★★";
            case 3: return "良好 ★★★★☆";
            case 2: return "一般 ★★★☆☆";
            case 1: return "较差 ★★☆☆☆";
            default: return "很差 ★☆☆☆☆";
        }
    }

    private int getChannel(int frequency) {
        if (frequency >= 2412 && frequency <= 2484) {
            return (frequency - 2412) / 5 + 1;
        } else if (frequency >= 5170 && frequency <= 5825) {
            return (frequency - 5170) / 5 + 34;
        }
        return -1;
    }

    public void stopWifiScan() {
        try {
            context.unregisterReceiver(wifiReceiver);
        } catch (IllegalArgumentException e) {
            // 接收器可能未注册，忽略异常
        }
        isScanning = false;
    }

    public boolean isScanning() {
        return isScanning;
    }
}